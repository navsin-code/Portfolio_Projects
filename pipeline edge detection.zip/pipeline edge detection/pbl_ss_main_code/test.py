import cv2
import numpy as np
import matplotlib.pyplot as plt
from tensorflow import keras
from keras.models import load_model

# Load the trained model
print("Loading trained model...")
model = load_model('best_pipe_sobel_model1.h5')
print("Model loaded successfully!")

def preprocess_blueprint_sobel(image):
    """Same preprocessing as training"""
    filtered = cv2.bilateralFilter(image, 5, 50, 50)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4,4))
    enhanced = clahe.apply(filtered)
    return enhanced

def predict_pipe_edges(model, image):
    """Predict using trained model"""
    img_resized = cv2.resize(image, (128, 128))
    img_processed = preprocess_blueprint_sobel(img_resized)
    img_normalized = img_processed.astype(np.float32) / 255.0
    img_input = np.expand_dims(np.expand_dims(img_normalized, axis=-1), axis=0)
    
    prediction = model.predict(img_input, verbose=0)
    edge_mask = (prediction[0, :, :, 0] > 0.5).astype(np.uint8) * 255
    edge_mask = cv2.resize(edge_mask, (256, 256))
    return edge_mask

def apply_sobel(image):
    """Traditional Sobel edge detection"""
    sobel_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
    sobel = cv2.magnitude(sobel_x, sobel_y)
    sobel = cv2.normalize(sobel, None, 0, 255, cv2.NORM_MINMAX)
    return sobel.astype(np.uint8)

def compare_sobel_vs_model(image_path):
    """Compare Sobel vs Model predictions with 4 plots only"""
    # Load image
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        print(f"Error: Could not load image at {image_path}")
        return
    
    print(f"Processing image: {image_path}")
    original_image = cv2.resize(image, (256, 256))
    
    # Get model prediction
    print("Getting model prediction...")
    model_prediction = predict_pipe_edges(model, image)
    
    # Get Sobel result
    print("Applying Sobel edge detection...")
    sobel_result = apply_sobel(original_image)
    
    # Apply threshold to Sobel for fair comparison
    _, sobel_binary = cv2.threshold(sobel_result, 50, 255, cv2.THRESH_BINARY)
    
    # Clean up both results
    kernel = np.ones((3, 3), np.uint8)
    model_cleaned = cv2.morphologyEx(model_prediction, cv2.MORPH_CLOSE, kernel)
    sobel_cleaned = cv2.morphologyEx(sobel_binary, cv2.MORPH_CLOSE, kernel)
    
    # Create 2x2 plot with exactly 4 images
    plt.figure(figsize=(12, 10))
    
    # 1. Actual Image
    plt.subplot(2, 2, 1)
    plt.imshow(original_image, cmap='gray')
    plt.title('Actual Image', fontsize=14)
    plt.axis('off')
    
    # 2. Model Predicted Image
    plt.subplot(2, 2, 2)
    plt.imshow(model_cleaned, cmap='gray')
    plt.title('Model Predicted Image', fontsize=14)
    plt.axis('off')
    
    # 3. Sobel Direct Image
    plt.subplot(2, 2, 3)
    plt.imshow(sobel_cleaned, cmap='gray')
    plt.title('Sobel Direct Image', fontsize=14)
    plt.axis('off')
    
    # 4. Comparison between Model and Sobel
    plt.subplot(2, 2, 4)
    difference = cv2.absdiff(sobel_cleaned, model_cleaned)
    plt.imshow(difference, cmap='hot')
    plt.title('Comparison (Model vs Sobel)', fontsize=14)
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()
    
    # Calculate similarity metrics
    sobel_edges = np.sum(sobel_cleaned > 0)
    model_edges = np.sum(model_cleaned > 0)
    common_edges = np.sum((sobel_cleaned > 0) & (model_cleaned > 0))
    
    if sobel_edges > 0:
        similarity = common_edges / sobel_edges * 100
    else:
        similarity = 0
    
    print("\n" + "="*50)
    print("COMPARISON RESULTS:")
    print("="*50)
    print(f"Sobel detected edges: {sobel_edges} pixels")
    print(f"Model detected edges: {model_edges} pixels")
    print(f"Common edges: {common_edges} pixels")
    print(f"Similarity to Sobel: {similarity:.1f}%")
    print("="*50)
    
    return sobel_cleaned, model_cleaned

# =============================================================================
# MAIN EXECUTION - ADD YOUR IMAGE PATH HERE
# =============================================================================

if __name__ == "__main__":
    # TODO: Replace with your image path
    image_path = r"C:\Users\Navya Singh\Downloads\try.png"# <-- ADD YOUR IMAGE PATH HERE
    
    if not image_path:
        print("Please add your image path in the image_path variable")
        print("Example: image_path = r'C:\\Users\\YourName\\Desktop\\pipe_image.jpg'")
    else:
        # Compare Sobel vs Model
        result = compare_sobel_vs_model(image_path)
        
        if result:
            print("\n🔍 Analysis complete!")
            print("Check the 4-plot comparison above.")