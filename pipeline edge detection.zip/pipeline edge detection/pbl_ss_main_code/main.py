import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
import keras
from keras import layers, models
from keras.optimizers import Adam
from keras.callbacks import ModelCheckpoint, ReduceLROnPlateau, EarlyStopping
import matplotlib.pyplot as plt
import tensorflow as tf

# Dataset paths
dataset_path = r"C:\Users\Navya Singh\Downloads\all_pipes"
image_path = r"C:\Users\Navya Singh\Downloads\all_pipes\pipe_206_left_L81_W66_A83.png"

def preprocess_blueprint_sobel(image):
    """Enhanced preprocessing for blueprint images"""
    filtered = cv2.bilateralFilter(image, 5, 50, 50)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4, 4))
    enhanced = clahe.apply(filtered)
    return enhanced

def create_sobel_edge_mask(image):
    """Create Sobel edge detection mask"""
    sobel_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
    sobel_combined = np.sqrt(sobel_x**2 + sobel_y**2)
    sobel_normalized = cv2.normalize(sobel_combined, None, 0, 255, cv2.NORM_MINMAX)
    sobel_edges = sobel_normalized.astype(np.uint8)
    _, binary_mask = cv2.threshold(sobel_edges, 50, 255, cv2.THRESH_BINARY)
    kernel = np.ones((3, 3), np.uint8)
    cleaned_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_CLOSE, kernel)
    return cleaned_mask

def augment_blueprint_data_fast(images, masks):
    """Fast data augmentation for blueprint images"""
    augmented_images = []
    augmented_masks = []
    for img, mask in zip(images, masks):
        augmented_images.append(img)
        augmented_masks.append(mask)
        img_90 = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
        mask_90 = cv2.rotate(mask, cv2.ROTATE_90_CLOCKWISE)
        augmented_images.append(img_90)
        augmented_masks.append(mask_90)
        img_180 = cv2.rotate(img, cv2.ROTATE_180)
        mask_180 = cv2.rotate(mask, cv2.ROTATE_180)
        augmented_images.append(img_180)
        augmented_masks.append(mask_180)
        img_flip = cv2.flip(img, 1)
        mask_flip = cv2.flip(mask, 1)
        augmented_images.append(img_flip)
        augmented_masks.append(mask_flip)
    return np.array(augmented_images), np.array(augmented_masks)

def build_light_unet():
    """Build lightweight U-Net model for edge detection"""
    inputs = layers.Input(shape=(128, 128, 1))
    conv1 = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(inputs)
    conv1 = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(conv1)
    pool1 = layers.MaxPooling2D(pool_size=(2, 2))(conv1)
    conv2 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(pool1)
    conv2 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(conv2)
    pool2 = layers.MaxPooling2D(pool_size=(2, 2))(conv2)
    conv3 = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(pool2)
    conv3 = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(conv3)
    pool3 = layers.MaxPooling2D(pool_size=(2, 2))(conv3)
    conv4 = layers.Conv2D(256, (3, 3), activation='relu', padding='same')(pool3)
    conv4 = layers.Conv2D(256, (3, 3), activation='relu', padding='same')(conv4)
    up5 = layers.Conv2DTranspose(128, (2, 2), strides=(2, 2), padding='same')(conv4)
    up5 = layers.Concatenate()([up5, conv3])
    conv5 = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(up5)
    conv5 = layers.Conv2D(128, (3, 3), activation='relu', padding='same')(conv5)
    up6 = layers.Conv2DTranspose(64, (2, 2), strides=(2, 2), padding='same')(conv5)
    up6 = layers.Concatenate()([up6, conv2])
    conv6 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(up6)
    conv6 = layers.Conv2D(64, (3, 3), activation='relu', padding='same')(conv6)
    up7 = layers.Conv2DTranspose(32, (2, 2), strides=(2, 2), padding='same')(conv6)
    up7 = layers.Concatenate()([up7, conv1])
    conv7 = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(up7)
    conv7 = layers.Conv2D(32, (3, 3), activation='relu', padding='same')(conv7)
    outputs = layers.Conv2D(1, (1, 1), activation='sigmoid')(conv7)
    model = models.Model(inputs=[inputs], outputs=[outputs])
    return model

def load_data_extended_training():
    """Load data for extended training with more images"""
    if not os.path.exists(dataset_path):
        print(f"Error: Dataset directory does not exist: {dataset_path}")
        return None, None
    images = []
    masks = []
    valid_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif']
    files = []
    for ext in valid_extensions:
        files.extend([f for f in os.listdir(dataset_path) if f.lower().endswith(ext.lower())])
    print(f"Found {len(files)} image files")
    if len(files) == 0:
        print("No image files found.")
        return None, None
    max_images = min(len(files), 100)
    files = files[:max_images]
    print(f"Using {len(files)} images for extended training")
    successful_loads = 0
    for i, filename in enumerate(files):
        try:
            img_path = os.path.join(dataset_path, filename)
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            if img is None:
                print(f"Warning: Could not load {filename}")
                continue
            img = cv2.resize(img, (128, 128))
            processed_img = preprocess_blueprint_sobel(img)
            sobel_mask = create_sobel_edge_mask(processed_img)
            images.append(processed_img)
            masks.append(sobel_mask)
            successful_loads += 1
            print(f"Processed {successful_loads}/{len(files)} images", end='\r')
        except Exception as e:
            print(f"Error processing {filename}: {str(e)}")
            continue
    print(f"\nSuccessfully loaded {len(images)} images")
    if len(images) == 0:
        print("No images were successfully processed!")
        return None, None
    images_array = np.array(images)
    masks_array = np.array(masks)
    print("Applying data augmentation...")
    augmented_images, augmented_masks = augment_blueprint_data_fast(images_array, masks_array)
    print(f"After augmentation: {len(augmented_images)} samples")
    return augmented_images, augmented_masks

def evaluate_model_performance(model, X_test, y_test):
    """Evaluate model performance with comprehensive metrics"""
    predictions = model.predict(X_test)
    pred_binary = (predictions > 0.5).astype(np.uint8)
    y_test_binary = (y_test > 0.5).astype(np.uint8)
    ssims = []
    rmses = []
    accuracies = []
    for i in range(len(X_test)):
        from skimage.metrics import structural_similarity as ssim
        ssim_val = ssim(y_test_binary[i].squeeze(), pred_binary[i].squeeze())
        ssims.append(ssim_val)
        rmse = np.sqrt(np.mean((y_test[i] - predictions[i]) ** 2))
        rmses.append(rmse)
        accuracy = np.mean(y_test_binary[i] == pred_binary[i])
        accuracies.append(accuracy)
    return {
        'ssim_mean': np.mean(ssims),
        'ssim_std': np.std(ssims),
        'rmse_mean': np.mean(rmses),
        'rmse_std': np.std(rmses),
        'accuracy_mean': np.mean(accuracies),
        'accuracy_std': np.std(accuracies)
    }

def plot_training_results(history, metrics=None):
    """Plot training accuracy and loss"""
    plt.figure(figsize=(10, 4))
    # Plot 1: Model Accuracy
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'], label='Training Accuracy', linewidth=2)
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy', linewidth=2)
    plt.title('Model Accuracy', fontsize=12, fontweight='bold')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.grid(True, alpha=0.3)
    # Plot 2: Model Loss
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'], label='Training Loss', linewidth=2)
    plt.plot(history.history['val_loss'], label='Validation Loss', linewidth=2)
    plt.title('Model Loss', fontsize=12, fontweight='bold')
    plt.xlabel('Epoch')
    plt.ylabel('Binary Crossentropy Loss')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('training_results.png', dpi=300, bbox_inches='tight')
    plt.show()

# Main execution with EXTENDED TRAINING
if __name__ == "__main__":
    print("=" * 60)
    print("STARTING EXTENDED TRAINING WITH MORE EPOCHS AND IMAGES")
    print("=" * 60)
    print("\nLoading extended dataset...")
    images, masks = load_data_extended_training()
    if images is None or len(images) == 0:
        print("No data loaded. Exiting...")
        exit()
    print(f"Loaded {len(images)} images for extended training")
    print("\nPreprocessing data...")
    images = images.astype(np.float32) / 255.0
    masks = masks.astype(np.float32) / 255.0
    images = np.expand_dims(images, axis=-1)
    masks = np.expand_dims(masks, axis=-1)
    X_train, X_val, y_train, y_val = train_test_split(
        images, masks, test_size=0.2, random_state=42
    )
    print(f"Training set: {X_train.shape}")
    print(f"Validation set: {X_val.shape}")
    print("\nBuilding U-Net model...")
    model = build_light_unet()
    model.compile(
        optimizer=Adam(learning_rate=1e-3),
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    print("\nModel Architecture:")
    model.summary()
    callbacks = [
        ModelCheckpoint('best_pipe_extended_model.h5', save_best_only=True, 
                       monitor='val_loss', verbose=1),
        ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=8, 
                         min_lr=1e-7, verbose=1),
        EarlyStopping(monitor='val_loss', patience=15, restore_best_weights=True, verbose=1)
    ]
    print(f"\nTraining model with EXTENDED configuration...")
    print(f"Training for up to 10 epochs with {len(X_train)} samples...")
    print(f"Estimated training time: ~10-20 minutes")
    print("=" * 60)
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=10,
        batch_size=8,
        callbacks=callbacks,
        verbose=1
    )
    print("\n" + "=" * 60)
    print("TRAINING COMPLETED!")
    print("=" * 60)
    print("\nEvaluating model performance...")
    metrics = evaluate_model_performance(model, X_val, y_val)
    print("\nGenerating training visualization...")
    plot_training_results(history, metrics)
    print("\nFINAL RESULTS:")
    print("=" * 40)
    print(f"Model saved as 'best_pipe_extended_model.h5'")
    print(f"Trained on {len(X_train)} samples")
    print(f"Trained for {len(history.history['loss'])} epochs")
    print(f"Final training accuracy: {history.history['accuracy'][-1]:.4f}")
    print(f"Final validation accuracy: {history.history['val_accuracy'][-1]:.4f}")
    if metrics:
        print(f"Test SSIM: {metrics['ssim_mean']:.4f} ± {metrics['ssim_std']:.4f}")
        print(f"Test RMSE: {metrics['rmse_mean']:.4f} ± {metrics['rmse_std']:.4f}")
        print(f"Test Accuracy: {metrics['accuracy_mean']:.4f} ± {metrics['accuracy_std']:.4f}")
    print("=" * 40)
    print("TRAINING COMPLETED SUCCESSFULLY!")
    print("Results saved as 'training_results.png'")
    print("=" * 40)