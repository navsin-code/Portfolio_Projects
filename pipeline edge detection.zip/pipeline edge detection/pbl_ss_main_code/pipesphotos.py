from PIL import Image, ImageDraw
import os
import numpy as np

# Function to generate a blueprint with multiple pipe directions
def generate_blueprint(num_pipes, output_path, img_size=(64, 64)):
    # Create a blank 64x64 image with a blue background
    img = Image.new('RGB', img_size, color=(0, 100, 150))  # Blue background
    draw = ImageDraw.Draw(img)

    # Draw a grid (10x10 cm grid scaled to 64x64 pixels)
    grid_size = 10  # Each grid square represents 10 cm
    pixel_per_cm = img_size[0] / 100  # 100 cm = 64 pixels, so 1 cm = 0.64 pixels
    grid_step = int(grid_size * pixel_per_cm)  # Grid lines every 10 cm

    for i in range(0, img_size[0], grid_step):
        draw.line([(i, 0), (i, img_size[1])], fill=(50, 150, 200), width=1)  # Vertical grid
        draw.line([(0, i), (img_size[1], i)], fill=(50, 150, 200), width=1)  # Horizontal grid

    # Pipe thickness (in pixels)
    pipe_thickness = 6  # Fixed thickness for visibility
    margin = 10

    # Center point of the blueprint
    center_x = img_size[0] // 2 - pipe_thickness // 2
    center_y = img_size[1] // 2

    for _ in range(num_pipes):
        # Randomly generate length, width, and angle
        length = np.random.randint(10, 40) * pixel_per_cm  # Shorter lengths to fit multiple pipes
        width = np.random.randint(10, 30) * pixel_per_cm   # Shorter widths
        angle = np.random.randint(0, 360)  # Random angle from 0 to 360 degrees
        turn_type = np.random.choice(["left", "right"])  # Random turn direction

        # Calculate the end point of the initial segment
        angle_rad = np.deg2rad(angle)
        end_x = center_x + length * np.cos(angle_rad)
        end_y = center_y - length * np.sin(angle_rad)

        # Adjust end point to stay within bounds
        if end_x < margin:
            end_x = margin
        elif end_x > img_size[0] - margin:
            end_x = img_size[0] - margin
        if end_y < margin:
            end_y = margin
        elif end_y > img_size[1] - margin:
            end_y = img_size[1] - margin

        # Draw the initial segment
        draw.line(
            [(center_x + pipe_thickness // 2, center_y), (end_x, end_y)],
            fill=(255, 255, 255),
            width=pipe_thickness
        )

        # Calculate the second segment with a turn
        turn_angle = np.deg2rad(np.random.randint(30, 90))  # Turn angle between 30 and 90 degrees
        if turn_type == "right":
            turn_angle = -turn_angle
        new_angle = angle_rad + turn_angle
        end_x2 = end_x + width * np.cos(new_angle)
        end_y2 = end_y - width * np.sin(new_angle)

        # Adjust second end point to stay within bounds
        if end_x2 < margin:
            end_x2 = margin
        elif end_x2 > img_size[0] - margin:
            end_x2 = img_size[0] - margin
        if end_y2 < margin:
            end_y2 = margin
        elif end_y2 > img_size[1] - margin:
            end_y2 = img_size[1] - margin

        # Draw the second segment
        draw.line(
            [(end_x, end_y), (end_x2, end_y2)],
            fill=(255, 255, 255),
            width=pipe_thickness
        )

    # Save the blueprint image
    img.save(output_path)

# Parameters
output_folder = r"C:\Users\Navya Singh\Downloads\newpipes"
if not os.path.exists(output_folder):
    os.makedirs(output_folder)
output_path = os.path.join(output_folder, "blueprint.png")
num_pipes = 5  # Number of pipe directions

# Generate the blueprint
generate_blueprint(num_pipes, output_path)
print(f"Generated: {output_path}")