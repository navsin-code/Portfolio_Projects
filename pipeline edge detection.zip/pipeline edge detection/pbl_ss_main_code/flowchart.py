import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, ConnectionPatch
import numpy as np

def create_cnn_model_flowchart():
    """Create detailed CNN model architecture flowchart"""
    fig, ax = plt.subplots(1, 1, figsize=(14, 20))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 22)
    ax.axis('off')
    
    # Title
    ax.text(7, 21, 'U-Net CNN Model Architecture Flow', 
            fontsize=18, fontweight='bold', ha='center')
    
    # Helper function to create boxes
    def create_box(x, y, width, height, text, color, text_size=9):
        box = FancyBboxPatch(
            (x - width/2, y - height/2), width, height,
            boxstyle="round,pad=0.1",
            facecolor=color,
            edgecolor='black',
            linewidth=1.5
        )
        ax.add_patch(box)
        ax.text(x, y, text, ha='center', va='center', 
                fontsize=text_size, fontweight='bold', wrap=True)
    
    # Helper function to create arrows
    def create_arrow(x1, y1, x2, y2, color='black'):
        arrow = ConnectionPatch((x1, y1), (x2, y2), "data", "data",
                              arrowstyle="->", shrinkA=5, shrinkB=5,
                              mutation_scale=20, fc=color, lw=2)
        ax.add_patch(arrow)
    
    # INPUT STAGE
    create_box(7, 19.5, 6, 1, 'Input Image\nGrayscale Pipeline Blueprint\n128×128×1', '#E6F3FF')
    
    # PREPROCESSING STAGE  
    create_arrow(7, 19, 7, 18.3)
    create_box(7, 17.8, 6, 1, 'Preprocessing Pipeline\nBilateral Filter + CLAHE\nNormalize (0-1)', '#D4E6F1')
    
    # GROUND TRUTH GENERATION
    create_arrow(7, 17.3, 7, 16.6)
    create_box(7, 16.1, 6, 1, 'Ground Truth Generation\nSobel Edge Detection\nThreshold + Morphological Cleanup', '#A9CCE3')
    
    # ENCODER PATH (Left side)
    create_arrow(7, 15.6, 4, 15)
    ax.text(2, 14.5, 'ENCODER PATH', fontsize=12, fontweight='bold', ha='center', rotation=90)
    
    create_box(4, 14.5, 4, 0.8, 'Conv Block 1\n32 filters, 3×3, ReLU\n128×128×32', '#7FB3D3')
    create_arrow(4, 14.1, 4, 13.6)
    create_box(4, 13.2, 4, 0.8, 'MaxPool 1\n2×2 pooling\n64×64×32', '#6BA6CD')
    
    create_arrow(4, 12.8, 4, 12.3)
    create_box(4, 11.9, 4, 0.8, 'Conv Block 2\n64 filters, 3×3, ReLU\n64×64×64', '#5499C7')
    create_arrow(4, 11.5, 4, 11)
    create_box(4, 10.6, 4, 0.8, 'MaxPool 2\n2×2 pooling\n32×32×64', '#4A90C2')
    
    create_arrow(4, 10.2, 4, 9.7)
    create_box(4, 9.3, 4, 0.8, 'Conv Block 3\n128 filters, 3×3, ReLU\n32×32×128', '#3F87BD')
    create_arrow(4, 8.9, 4, 8.4)
    create_box(4, 8, 4, 0.8, 'MaxPool 3\n2×2 pooling\n16×16×128', '#357AB8')
    
    # BOTTLENECK
    create_arrow(4, 7.6, 7, 7)
    create_box(7, 6.5, 5, 1, 'BOTTLENECK\nConv Block 4\n256 filters, 3×3, ReLU\n16×16×256', '#FFE6CC')
    
    # DECODER PATH (Right side)
    create_arrow(7, 6, 10, 5.5)
    ax.text(12, 14.5, 'DECODER PATH', fontsize=12, fontweight='bold', ha='center', rotation=90)
    
    create_box(10, 8, 4, 0.8, 'UpConv 1\nTranspose Conv 2×2\n32×32×128', '#F8D7DA')
    create_arrow(10, 7.6, 10, 7.1)
    create_box(10, 9.3, 4, 0.8, 'Skip Connection 1\nConcatenate with Conv3\n32×32×256', '#F1C2C7')
    create_arrow(10, 8.9, 10, 8.4)
    
    create_box(10, 10.6, 4, 0.8, 'UpConv 2\nTranspose Conv 2×2\n64×64×64', '#EAACB4')
    create_arrow(10, 10.2, 10, 9.7)
    create_box(10, 11.9, 4, 0.8, 'Skip Connection 2\nConcatenate with Conv2\n64×64×128', '#E395A1')
    create_arrow(10, 11.5, 10, 11)
    
    create_box(10, 13.2, 4, 0.8, 'UpConv 3\nTranspose Conv 2×2\n128×128×32', '#DC7F8E')
    create_arrow(10, 12.8, 10, 12.3)
    create_box(10, 14.5, 4, 0.8, 'Skip Connection 3\nConcatenate with Conv1\n128×128×64', '#D5697B')
    create_arrow(10, 14.1, 10, 13.6)
    
    # Skip connection arrows
    create_arrow(6, 14.5, 8, 14.5, 'red')  # Skip 1
    create_arrow(6, 11.9, 8, 11.9, 'red')  # Skip 2  
    create_arrow(6, 9.3, 8, 9.3, 'red')    # Skip 3
    
    # OUTPUT STAGE
    create_arrow(10, 8, 7, 5)
    create_box(7, 4.5, 5, 1, 'Output Layer\n1×1 Conv, Sigmoid\n128×128×1\nProbability Map', '#E395A1')
    
    create_arrow(7, 4, 7, 3.3)
    create_box(7, 2.8, 5, 1, 'Post-Processing\nThreshold (0.3 or 0.6)\nBinary Edge Map\n128×128×1', '#C39BD3')
    
    create_arrow(7, 2.3, 7, 1.6)
    create_box(7, 1.1, 5, 1, 'Final Output\nPipe Edge Detection\nResized to Original\n256×256×1', '#A569BD')
    
    # Add legend
    ax.text(0.5, 0.5, 'Legend:\nBlue: Encoder | Orange: Bottleneck | Pink: Decoder\nRed Arrows: Skip Connections', 
            fontsize=10, ha='left', va='bottom', 
            bbox=dict(boxstyle="round,pad=0.3", facecolor='lightgray'))
    
    plt.tight_layout()
    plt.savefig('cnn_model_architecture_flow.png', dpi=300, bbox_inches='tight')
    plt.show()

def create_data_pipeline_flowchart():
    """Create data processing pipeline flowchart"""
    fig, ax = plt.subplots(1, 1, figsize=(12, 16))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 18)
    ax.axis('off')
    
    # Title
    ax.text(6, 17, 'Data Processing Pipeline', 
            fontsize=18, fontweight='bold', ha='center')
    
    def create_box(x, y, width, height, text, color, text_size=9):
        box = FancyBboxPatch(
            (x - width/2, y - height/2), width, height,
            boxstyle="round,pad=0.1",
            facecolor=color,
            edgecolor='black',
            linewidth=1.5
        )
        ax.add_patch(box)
        ax.text(x, y, text, ha='center', va='center', 
                fontsize=text_size, fontweight='bold')
    
    def create_arrow(x1, y1, x2, y2, color='black'):
        arrow = ConnectionPatch((x1, y1), (x2, y2), "data", "data",
                              arrowstyle="->", shrinkA=5, shrinkB=5,
                              mutation_scale=20, fc=color, lw=2)
        ax.add_patch(arrow)
    
    # Data pipeline stages
    create_box(6, 15.5, 8, 1, 'Raw Dataset\n1826 Pipeline Images\nPNG Format, Various Sizes', '#FFE6E6')
    
    create_arrow(6, 15, 6, 14.3)
    create_box(6, 13.8, 8, 1, 'Dataset Selection\n100 Representative Images\nDiverse Pipeline Configurations', '#FFD6CC')
    
    create_arrow(6, 13.3, 6, 12.6)
    create_box(6, 12.1, 8, 1, 'Image Preprocessing\nBilateral Filter (5×5, σ=50)\nCLAHE (clipLimit=2.0)\nResize to 128×128', '#FFC6B3')
    
    create_arrow(6, 11.6, 6, 10.9)
    create_box(6, 10.4, 8, 1, 'Ground Truth Generation\nSobel Edge Detection\nThreshold=50, Binary Conversion\nMorphological Cleanup', '#FFB399')
    
    create_arrow(6, 9.9, 6, 9.2)
    create_box(6, 8.7, 8, 1, 'Data Augmentation\n4× Expansion Strategy\nOriginal + 90° + 180° + H-Flip\n400 Total Samples', '#FFA080')
    
    # Split into train/validation
    create_arrow(6, 8.2, 3, 7.5)
    create_arrow(6, 8.2, 9, 7.5)
    
    create_box(3, 7, 4, 1, 'Training Set\n320 Samples (80%)\nUsed for Model Training', '#80FF80')
    create_box(9, 7, 4, 1, 'Validation Set\n80 Samples (20%)\nUsed for Model Validation', '#80E6FF')
    
    # Training process
    create_arrow(3, 6.5, 3, 5.8)
    create_box(3, 5.3, 4, 1, 'Model Training\nBatch Size: 8\nEpochs: 10\nAdam Optimizer', '#66FF66')
    
    create_arrow(3, 4.8, 6, 4.3)
    create_box(6, 3.8, 6, 1, 'Model Evaluation\nSSIM, RMSE, Accuracy\nTPR, FPR, TNR Metrics', '#E6E6FA')
    
    create_arrow(6, 3.3, 6, 2.6)
    create_box(6, 2.1, 6, 1, 'Model Deployment\nSaved as .h5 file\nReady for Inference', '#DDA0DD')
    
    # Test images
    create_arrow(9, 6.5, 9, 5.8)
    create_box(9, 5.3, 4, 1, 'Test Images\nUnseen Pipeline Images\nPerformance Validation', '#ADD8E6')
    
    create_arrow(9, 4.8, 6, 4.3)
    
    plt.tight_layout()
    plt.savefig('data_pipeline_flowchart.png', dpi=300, bbox_inches='tight')
    plt.show()

def create_model_thinking_process():
    """Create flowchart showing how the model 'thinks'"""
    fig, ax = plt.subplots(1, 1, figsize=(14, 18))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 20)
    ax.axis('off')
    
    # Title
    ax.text(7, 19, 'How the CNN Model "Thinks" - Cognitive Process', 
            fontsize=16, fontweight='bold', ha='center')
    
    def create_box(x, y, width, height, text, color, text_size=9):
        box = FancyBboxPatch(
            (x - width/2, y - height/2), width, height,
            boxstyle="round,pad=0.1",
            facecolor=color,
            edgecolor='black',
            linewidth=1.5
        )
        ax.add_patch(box)
        ax.text(x, y, text, ha='center', va='center', 
                fontsize=text_size, fontweight='bold')
    
    def create_arrow(x1, y1, x2, y2, color='black'):
        arrow = ConnectionPatch((x1, y1), (x2, y2), "data", "data",
                              arrowstyle="->", shrinkA=5, shrinkB=5,
                              mutation_scale=20, fc=color, lw=2)
        ax.add_patch(arrow)
    
    # Model thinking process
    create_box(7, 17.5, 10, 1, 'Step 1: Initial Observation\n"I see a 128×128 grayscale image with various intensities"', '#E6F3FF', 10)
    
    create_arrow(7, 17, 7, 16.3)
    create_box(7, 15.8, 10, 1, 'Step 2: Basic Feature Detection\n"Let me scan for basic patterns: lines, edges, corners"\n32 different pattern detectors activate', '#D4E6F1', 10)
    
    create_arrow(7, 15.3, 7, 14.6)
    create_box(7, 14.1, 10, 1, 'Step 3: Pattern Combination\n"I found horizontal lines here, vertical lines there"\n"Let me combine them into T-joints, L-corners, pipe segments"', '#A9CCE3', 10)
    
    create_arrow(7, 13.6, 7, 12.9)
    create_box(7, 12.4, 10, 1, 'Step 4: Complex Shape Recognition\n"These combined patterns form pipe structures"\n"I can see complete pipe sections and networks"', '#7FB3D3', 10)
    
    create_arrow(7, 11.9, 7, 11.2)
    create_box(7, 10.7, 10, 1, 'Step 5: Contextual Understanding\n"This is a pipeline system with specific topology"\n"I understand the overall structure and relationships"', '#FFE6CC', 10)
    
    create_arrow(7, 10.2, 7, 9.5)
    create_box(7, 9, 10, 1, 'Step 6: Reconstruction Planning\n"Now I need to rebuild this understanding"\n"But I must preserve exact spatial locations"', '#F8D7DA', 10)
    
    create_arrow(7, 8.5, 7, 7.8)
    create_box(7, 7.3, 10, 1, 'Step 7: Detail Recovery\n"Let me use my saved fine details (skip connections)"\n"Combine abstract understanding with precise locations"', '#F1C2C7', 10)
    
    create_arrow(7, 6.8, 7, 6.1)
    create_box(7, 5.6, 10, 1, 'Step 8: Progressive Refinement\n"Build up resolution layer by layer"\n"Ensure each pixel gets correct edge probability"', '#EAACB4', 10)
    
    create_arrow(7, 5.1, 7, 4.4)
    create_box(7, 3.9, 10, 1, 'Step 9: Final Decision\n"For each pixel: Edge or No Edge?"\n"Apply sigmoid: convert to probability (0-1)"', '#E395A1', 10)
    
    create_arrow(7, 3.4, 7, 2.7)
    create_box(7, 2.2, 10, 1, 'Step 10: Confident Output\n"I am 90% sure this pixel is an edge"\n"Final binary decision based on threshold"', '#C39BD3', 10)
    
    # Side annotations
    ax.text(1, 15, 'ENCODER\nTHINKING', fontsize=12, fontweight='bold', ha='center', rotation=90, 
            bbox=dict(boxstyle="round,pad=0.3", facecolor='lightblue'))
    
    ax.text(1, 7, 'DECODER\nTHINKING', fontsize=12, fontweight='bold', ha='center', rotation=90,
            bbox=dict(boxstyle="round,pad=0.3", facecolor='lightpink'))
    
    plt.tight_layout()
    plt.savefig('model_thinking_process.png', dpi=300, bbox_inches='tight')
    plt.show()

def create_all_flowcharts():
    """Generate all flowcharts"""
    print("Creating CNN Model Architecture Flowchart...")
    create_cnn_model_flowchart()
    
    print("Creating Data Pipeline Flowchart...")
    create_data_pipeline_flowchart()
    
    print("Creating Model Thinking Process Flowchart...")
    create_model_thinking_process()
    
    print("All flowcharts created successfully!")

if __name__ == "__main__":
    create_all_flowcharts()