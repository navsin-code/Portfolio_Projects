import cv2
import numpy as np
import matplotlib.pyplot as plt
from keras.models import load_model
from skimage.metrics import structural_similarity as ssim
from sklearn.metrics import confusion_matrix, accuracy_score
import os

# Load the trained model - ENHANCED VERSION
print("Loading trained model...")
try:
    model = load_model("best_pipe_extended_model.h5")
    print("✅ Extended model loaded successfully!")
    current_model = "Extended Model"
except:
    print("⚠️ Extended model not found, trying original model...")
    try:
        model = load_model('best_pipe_extended_model.h5')
        print("✅ Original model loaded successfully!")
        current_model = "Original Model"
    except:
        print("❌ No trained model found! Please train a model first.")
        exit()

print(f"Currently using: {current_model}")

def preprocess_blueprint_sobel(image):
    """EXACT same preprocessing as training"""
    # Apply bilateral filter to reduce noise while preserving edges
    filtered = cv2.bilateralFilter(image, 5, 50, 50)
    
    # Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4, 4))
    enhanced = clahe.apply(filtered)
    
    return enhanced

def predict_pipe_edges(model, image):
    """ENHANCED prediction using trained model"""
    # Resize to model input size
    img_resized = cv2.resize(image, (128, 128))
    
    # Apply same preprocessing as training
    img_processed = preprocess_blueprint_sobel(img_resized)
    
    # Normalize to 0-1 range
    img_normalized = img_processed.astype(np.float32) / 127.0
    
    # Add batch and channel dimensions
    img_input = np.expand_dims(np.expand_dims(img_normalized, axis=-1), axis=0)
    
    # Get prediction
    prediction = model.predict(img_input, verbose=0)
    
    # Convert to binary mask with OPTIMIZED threshold
    edge_mask = (prediction[0, :, :, 0] > 0.85).astype(np.uint8) * 127  # LOWERED from 0.5 to 0.3
    
    # Resize back to target size
    edge_mask = cv2.resize(edge_mask, (256, 256))
    
    # Apply morphological operations to clean up
    '''kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (1, 1))
    edge_mask = cv2.morphologyEx(edge_mask, cv2.MORPH_CLOSE, kernel)
    edge_mask = cv2.morphologyEx(edge_mask, cv2.MORPH_OPEN, kernel)'''
    
    return edge_mask

def predict_pipe_edges_multiple_thresholds(model, image):
    """Get predictions at multiple thresholds for analysis"""
    # Resize to model input size
    img_resized = cv2.resize(image, (128, 128))
    
    # Apply same preprocessing as training
    img_processed = preprocess_blueprint_sobel(img_resized)
    
    # Normalize to 0-1 range
    img_normalized = img_processed.astype(np.float32) / 127.0
    
    # Add batch and channel dimensions
    img_input = np.expand_dims(np.expand_dims(img_normalized, axis=-1), axis=0)
    
    # Get raw prediction
    prediction = model.predict(img_input, verbose=0)
    prob_map = prediction[0, :, :, 0]
    
    # Multiple thresholds
    thresholds = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    threshold_results = {}
    
    for thresh in thresholds:
        edge_mask = (prob_map > thresh).astype(np.uint8) * 127
        edge_mask = cv2.resize(edge_mask, (256, 256))
        
        # Apply morphological operations
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        edge_mask = cv2.morphologyEx(edge_mask, cv2.MORPH_CLOSE, kernel)
        edge_mask = cv2.morphologyEx(edge_mask, cv2.MORPH_OPEN, kernel)
        
        threshold_results[thresh] = edge_mask
    
    return threshold_results, prob_map

def apply_sobel_ground_truth(image):
    """ENHANCED Sobel ground truth generation"""
    # Apply preprocessing first (same as training)
    processed = preprocess_blueprint_sobel(image)
    
    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(processed, (3, 3), 0)
    
    # Sobel edge detection
    sobel_x = cv2.Sobel(blurred, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(blurred, cv2.CV_64F, 0, 1, ksize=3)
    
    # Combine Sobel gradients
    sobel_combined = np.sqrt(sobel_x**2 + sobel_y**2)
    
    # Normalize to 0-255
    sobel_normalized = cv2.normalize(sobel_combined, None, 0, 255, cv2.NORM_MINMAX)
    sobel_edges = sobel_normalized.astype(np.uint8)
    
    # Apply threshold to get binary edge mask
    _, binary_edges = cv2.threshold(sobel_edges, 50, 255, cv2.THRESH_BINARY)
    
    # Apply morphological operations to clean up
    kernel = np.ones((3, 3), np.uint8)
    cleaned_edges = cv2.morphologyEx(binary_edges, cv2.MORPH_CLOSE, kernel)
    
    return cleaned_edges

def calculate_ssim(ground_truth, prediction):
    """Calculate Structural Similarity Index (SSIM)"""
    # Ensure both images are in the same format
    gt_norm = ground_truth.astype(np.float64) / 127.0
    pred_norm = prediction.astype(np.float64) / 127.0
    
    # Calculate SSIM
    ssim_value = ssim(gt_norm, pred_norm, data_range=1.0)
    return ssim_value

def calculate_rmse(ground_truth, prediction):
    """Calculate Root Mean Square Error (RMSE)"""
    # Normalize both images to 0-1 range
    gt_norm = ground_truth.astype(np.float64) / 127.0
    pred_norm = prediction.astype(np.float64) / 127.0
    
    # Calculate RMSE
    mse = np.mean((gt_norm - pred_norm) ** 2)
    rmse = np.sqrt(mse)
    return rmse

def calculate_classification_metrics(ground_truth, prediction):
    """Calculate Accuracy, TPR, FPR, TNR"""
    # Convert to binary (0 or 1)
    gt_binary = (ground_truth > 127).astype(np.uint8)
    pred_binary = (prediction > 127).astype(np.uint8)
    
    # Flatten arrays for sklearn
    gt_flat = gt_binary.flatten()
    pred_flat = pred_binary.flatten()
    
    # Calculate confusion matrix
    tn, fp, fn, tp = confusion_matrix(gt_flat, pred_flat).ravel()
    
    # Calculate metrics
    accuracy = accuracy_score(gt_flat, pred_flat)
    
    # True Positive Rate (Sensitivity/Recall/TPR)
    tpr = tp / (tp + fn) if (tp + fn) > 0 else 0
    
    # False Positive Rate
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0
    
    # True Negative Rate (Specificity/TNR)
    tnr = tn / (tn + fp) if (tn + fp) > 0 else 0
    
    return accuracy, tpr, fpr, tnr, tp, fp, tn, fn

def find_optimal_threshold(model, image, ground_truth):
    """Find optimal threshold for given image"""
    threshold_results, prob_map = predict_pipe_edges_multiple_thresholds(model, image)
    
    best_threshold = 0.5
    best_ssim = 0
    threshold_metrics = {}
    
    for thresh, prediction in threshold_results.items():
        ssim_score = calculate_ssim(ground_truth, prediction)
        rmse_score = calculate_rmse(ground_truth, prediction)
        accuracy, tpr, fpr, tnr, tp, fp, tn, fn = calculate_classification_metrics(ground_truth, prediction)
        
        threshold_metrics[thresh] = {
            'ssim': ssim_score,
            'rmse': rmse_score,
            'accuracy': accuracy,
            'tpr': tpr,
            'fpr': fpr,
            'tnr': tnr
        }
        
        if ssim_score > best_ssim:
            best_ssim = ssim_score
            best_threshold = thresh
    
    return best_threshold, threshold_metrics, prob_map

def evaluate_single_image(image_path):
    """ENHANCED single image evaluation"""
    # Load image
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        print(f"Error: Could not load image at {image_path}")
        return None
    
    print(f"Evaluating image: {os.path.basename(image_path)}")
    original_image = cv2.resize(image, (256, 256))
    
    # Generate ground truth (Sobel)
    ground_truth = apply_sobel_ground_truth(original_image)
    
    # Get model prediction with default threshold
    model_prediction = predict_pipe_edges(model, image)
    
    # Find optimal threshold
    optimal_threshold, threshold_metrics, prob_map = find_optimal_threshold(model, image, ground_truth)
    
    # Get prediction with optimal threshold
    optimal_prediction = (cv2.resize(prob_map, (256, 256)) > optimal_threshold).astype(np.uint8) * 255
    
    # Calculate metrics for default threshold
    ssim_score = calculate_ssim(ground_truth, model_prediction)
    rmse_score = calculate_rmse(ground_truth, model_prediction)
    accuracy, tpr, fpr, tnr, tp, fp, tn, fn = calculate_classification_metrics(ground_truth, model_prediction)
    
    # Calculate metrics for optimal threshold
    ssim_optimal = calculate_ssim(ground_truth, optimal_prediction)
    rmse_optimal = calculate_rmse(ground_truth, optimal_prediction)
    accuracy_optimal, tpr_optimal, fpr_optimal, tnr_optimal, tp_opt, fp_opt, tn_opt, fn_opt = calculate_classification_metrics(ground_truth, optimal_prediction)
    
    # Store results
    results = {
        'image_path': image_path,
        'ssim': ssim_score,
        'rmse': rmse_score,
        'accuracy': accuracy,
        'tpr': tpr,
        'fpr': fpr,
        'tnr': tnr,
        'tp': tp, 'fp': fp, 'tn': tn, 'fn': fn,
        'optimal_threshold': optimal_threshold,
        'ssim_optimal': ssim_optimal,
        'rmse_optimal': rmse_optimal,
        'accuracy_optimal': accuracy_optimal,
        'tpr_optimal': tpr_optimal,
        'fpr_optimal': fpr_optimal,
        'tnr_optimal': tnr_optimal,
        'threshold_metrics': threshold_metrics,
        'ground_truth': ground_truth,
        'prediction': model_prediction,
        'optimal_prediction': optimal_prediction,
        'probability_map': prob_map,
        'original': original_image
    }
    
    return results

def evaluate_multiple_images(image_folder):
    """ENHANCED multiple images evaluation"""
    if not os.path.exists(image_folder):
        print(f"Error: Folder does not exist: {image_folder}")
        return None, None
    
    # Get all image files
    valid_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif']
    image_files = []
    for ext in valid_extensions:
        image_files.extend([f for f in os.listdir(image_folder) if f.lower().endswith(ext.lower())])
    
    if len(image_files) == 0:
        print("No image files found in the folder.")
        return None, None
    
    print(f"Found {len(image_files)} images to evaluate")
    
    all_results = []
    ssim_scores = []
    rmse_scores = []
    accuracy_scores = []
    tpr_scores = []
    fpr_scores = []
    tnr_scores = []
    
    ssim_optimal_scores = []
    rmse_optimal_scores = []
    accuracy_optimal_scores = []
    optimal_thresholds = []
    
    for filename in image_files:
        image_path = os.path.join(image_folder, filename)
        result = evaluate_single_image(image_path)
        
        if result:
            all_results.append(result)
            
            # Default threshold metrics
            ssim_scores.append(result['ssim'])
            rmse_scores.append(result['rmse'])
            accuracy_scores.append(result['accuracy'])
            tpr_scores.append(result['tpr'])
            fpr_scores.append(result['fpr'])
            tnr_scores.append(result['tnr'])
            
            # Optimal threshold metrics
            ssim_optimal_scores.append(result['ssim_optimal'])
            rmse_optimal_scores.append(result['rmse_optimal'])
            accuracy_optimal_scores.append(result['accuracy_optimal'])
            optimal_thresholds.append(result['optimal_threshold'])
    
    # Calculate average metrics
    avg_metrics = {
        # Default threshold (0.3)
        'avg_ssim': np.mean(ssim_scores),
        'avg_rmse': np.mean(rmse_scores),
        'avg_accuracy': np.mean(accuracy_scores),
        'avg_tpr': np.mean(tpr_scores),
        'avg_fpr': np.mean(fpr_scores),
        'avg_tnr': np.mean(tnr_scores),
        'std_ssim': np.std(ssim_scores),
        'std_rmse': np.std(rmse_scores),
        'std_accuracy': np.std(accuracy_scores),
        'std_tpr': np.std(tpr_scores),
        'std_fpr': np.std(fpr_scores),
        'std_tnr': np.std(tnr_scores),
        
        # Optimal threshold
        'avg_ssim_optimal': np.mean(ssim_optimal_scores),
        'avg_rmse_optimal': np.mean(rmse_optimal_scores),
        'avg_accuracy_optimal': np.mean(accuracy_optimal_scores),
        'avg_optimal_threshold': np.mean(optimal_thresholds),
        'std_ssim_optimal': np.std(ssim_optimal_scores),
        'std_rmse_optimal': np.std(rmse_optimal_scores),
        'std_accuracy_optimal': np.std(accuracy_optimal_scores),
        'std_optimal_threshold': np.std(optimal_thresholds)
    }
    
    return all_results, avg_metrics

def compare_models_performance():
    """Compare extended model vs original model performance"""
    models_to_test = []
    
    # Try to load both models
    try:
        extended_model = load_model('best_pipe_extended_model.h5')
        models_to_test.append(('Extended Model', extended_model))
        print("✅ Extended model loaded for comparison")
    except:
        print("⚠️ Extended model not found")
    
    try:
        original_model = load_model('best_pipe_extended_model.h5')
        models_to_test.append(('Original Model', original_model))
        print("✅ Original model loaded for comparison")
    except:
        print("⚠️ Original model not found")
    
    if len(models_to_test) < 2:
        print("Need both models for comparison")
        return
    
    # Test on a few sample images
    test_folder = input("Enter test folder path: ").strip().strip('"')
    if not os.path.exists(test_folder):
        print("Test folder not found")
        return
    
    # Get test images
    valid_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif']
    test_images = []
    for ext in valid_extensions:
        test_images.extend([f for f in os.listdir(test_folder) if f.lower().endswith(ext.lower())])
    
    test_images = test_images[:10]  # Test on 10 images
    
    print(f"\nComparing models on {len(test_images)} test images...")
    print("=" * 70)
    
    comparison_results = {}
    
    for model_name, test_model in models_to_test:
        print(f"\nTesting {model_name}:")
        ssim_scores = []
        rmse_scores = []
        accuracy_scores = []
        tpr_scores = []
        fpr_scores = []
        tnr_scores = []
        
        for img_file in test_images:
            img_path = os.path.join(test_folder, img_file)
            image = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            if image is None:
                continue
                
            original_image = cv2.resize(image, (256, 256))
            ground_truth = apply_sobel_ground_truth(original_image)
            
            # Get prediction using the test model
            prediction = predict_pipe_edges(test_model, image)
            
            # Calculate metrics
            ssim_score = calculate_ssim(ground_truth, prediction)
            rmse_score = calculate_rmse(ground_truth, prediction)
            accuracy, tpr, fpr, tnr, _, _, _, _ = calculate_classification_metrics(ground_truth, prediction)
            
            ssim_scores.append(ssim_score)
            rmse_scores.append(rmse_score)
            accuracy_scores.append(accuracy)
            tpr_scores.append(tpr)
            fpr_scores.append(fpr)
            tnr_scores.append(tnr)
        
        # Store results
        comparison_results[model_name] = {
            'ssim': np.mean(ssim_scores),
            'rmse': np.mean(rmse_scores),
            'accuracy': np.mean(accuracy_scores),
            'tpr': np.mean(tpr_scores),
            'fpr': np.mean(fpr_scores),
            'tnr': np.mean(tnr_scores),
            'ssim_std': np.std(ssim_scores),
            'rmse_std': np.std(rmse_scores),
            'accuracy_std': np.std(accuracy_scores)
        }
        
        print(f"  Average SSIM:     {np.mean(ssim_scores):.4f} ± {np.std(ssim_scores):.4f}")
        print(f"  Average RMSE:     {np.mean(rmse_scores):.4f} ± {np.std(rmse_scores):.4f}")
        print(f"  Average Accuracy: {np.mean(accuracy_scores):.4f} ± {np.std(accuracy_scores):.4f}")
        print(f"  Average TPR:      {np.mean(tpr_scores):.4f} ± {np.std(tpr_scores):.4f}")
        print(f"  Average FPR:      {np.mean(fpr_scores):.4f} ± {np.std(fpr_scores):.4f}")
        print(f"  Average TNR:      {np.mean(tnr_scores):.4f} ± {np.std(tnr_scores):.4f}")
    
    # Determine which model is better
    print("\n" + "=" * 70)
    print("🏆 MODEL COMPARISON RESULTS:")
    print("=" * 70)
    
    models = list(comparison_results.keys())
    if len(models) == 2:
        model1, model2 = models
        results1, results2 = comparison_results[model1], comparison_results[model2]
        
        print(f"\n📊 {model1} vs {model2}:")
        
        metrics = ['ssim', 'rmse', 'accuracy', 'tpr', 'tnr']
        better_count = {model1: 0, model2: 0}
        
        for metric in metrics:
            val1, val2 = results1[metric], results2[metric]
            
            if metric == 'rmse':  # Lower is better for RMSE
                winner = model1 if val1 < val2 else model2
                comparison = "<" if val1 < val2 else ">"
            else:  # Higher is better for others
                winner = model1 if val1 > val2 else model2
                comparison = ">" if val1 > val2 else "<"
            
            better_count[winner] += 1
            
            print(f"  {metric.upper()}: {val1:.4f} {comparison} {val2:.4f} → {winner} wins")
        
        # Overall winner
        overall_winner = model1 if better_count[model1] > better_count[model2] else model2
        print(f"\n🏆 OVERALL WINNER: {overall_winner}")
        print(f"   {overall_winner} wins in {max(better_count.values())}/5 metrics")

def print_detailed_results(result):
    """ENHANCED detailed results printing"""
    print("\n" + "="*70)
    print(f"DETAILED METRICS FOR: {os.path.basename(result['image_path'])}")
    print("="*70)
    
    # Default threshold results
    print(f"\n📊 DEFAULT THRESHOLD (0.3) RESULTS:")
    print(f"   SSIM (Structural Similarity):     {result['ssim']:.4f}")
    print(f"   RMSE (Root Mean Square Error):   {result['rmse']:.4f}")
    print(f"   Accuracy:                        {result['accuracy']:.4f} ({result['accuracy']*100:.2f}%)")
    print(f"   TPR (True Positive Rate):        {result['tpr']:.4f} ({result['tpr']*100:.2f}%)")
    print(f"   FPR (False Positive Rate):       {result['fpr']:.4f} ({result['fpr']*100:.2f}%)")
    print(f"   TNR (True Negative Rate):        {result['tnr']:.4f} ({result['tnr']*100:.2f}%)")
    
    # Optimal threshold results
    print(f"\n📊 OPTIMAL THRESHOLD ({result['optimal_threshold']:.1f}) RESULTS:")
    print(f"   SSIM (Structural Similarity):     {result['ssim_optimal']:.4f}")
    print(f"   RMSE (Root Mean Square Error):   {result['rmse_optimal']:.4f}")
    print(f"   Accuracy:                        {result['accuracy_optimal']:.4f} ({result['accuracy_optimal']*100:.2f}%)")
    print(f"   TPR (True Positive Rate):        {result['tpr_optimal']:.4f} ({result['tpr_optimal']*100:.2f}%)")
    print(f"   FPR (False Positive Rate):       {result['fpr_optimal']:.4f} ({result['fpr_optimal']*100:.2f}%)")
    print(f"   TNR (True Negative Rate):        {result['tnr_optimal']:.4f} ({result['tnr_optimal']*100:.2f}%)")
    
    # Improvement analysis
    ssim_improvement = result['ssim_optimal'] - result['ssim']
    accuracy_improvement = result['accuracy_optimal'] - result['accuracy']
    
    print(f"\n📈 IMPROVEMENT WITH OPTIMAL THRESHOLD:")
    print(f"   SSIM Improvement:     {ssim_improvement:+.4f}")
    print(f"   Accuracy Improvement: {accuracy_improvement:+.4f} ({accuracy_improvement*100:+.2f}%)")
    
    # Confusion matrix for default threshold
    print(f"\n📈 CONFUSION MATRIX (Default Threshold):")
    print(f"   True Positives (TP):  {result['tp']:,}")
    print(f"   False Positives (FP): {result['fp']:,}")
    print(f"   True Negatives (TN):  {result['tn']:,}")
    print(f"   False Negatives (FN): {result['fn']:,}")
    
    print("="*70)

def print_summary_results(avg_metrics, num_images):
    """ENHANCED summary results printing"""
    print("\n" + "="*70)
    print(f"SUMMARY METRICS FOR {num_images} IMAGES ({current_model})")
    print("="*70)
    
    # Default threshold results
    print(f"\n📊 DEFAULT THRESHOLD (0.3) PERFORMANCE:")
    print(f"   Average SSIM:         {avg_metrics['avg_ssim']:.4f} ± {avg_metrics['std_ssim']:.4f}")
    print(f"   Average RMSE:         {avg_metrics['avg_rmse']:.4f} ± {avg_metrics['std_rmse']:.4f}")
    print(f"   Average Accuracy:     {avg_metrics['avg_accuracy']:.4f} ± {avg_metrics['std_accuracy']:.4f} ({avg_metrics['avg_accuracy']*100:.2f}%)")
    print(f"   Average TPR:          {avg_metrics['avg_tpr']:.4f} ± {avg_metrics['std_tpr']:.4f} ({avg_metrics['avg_tpr']*100:.2f}%)")
    print(f"   Average FPR:          {avg_metrics['avg_fpr']:.4f} ± {avg_metrics['std_fpr']:.4f} ({avg_metrics['avg_fpr']*100:.2f}%)")
    print(f"   Average TNR:          {avg_metrics['avg_tnr']:.4f} ± {avg_metrics['std_tnr']:.4f} ({avg_metrics['avg_tnr']*100:.2f}%)")
    
    # Optimal threshold results
    print(f"\n📊 OPTIMAL THRESHOLD PERFORMANCE:")
    print(f"   Average Optimal Threshold: {avg_metrics['avg_optimal_threshold']:.2f} ± {avg_metrics['std_optimal_threshold']:.2f}")
    print(f"   Average SSIM (Optimal):    {avg_metrics['avg_ssim_optimal']:.4f} ± {avg_metrics['std_ssim_optimal']:.4f}")
    print(f"   Average RMSE (Optimal):    {avg_metrics['avg_rmse_optimal']:.4f} ± {avg_metrics['std_rmse_optimal']:.4f}")
    print(f"   Average Accuracy (Optimal): {avg_metrics['avg_accuracy_optimal']:.4f} ± {avg_metrics['std_accuracy_optimal']:.4f} ({avg_metrics['avg_accuracy_optimal']*100:.2f}%)")
    
    # Improvement analysis
    ssim_improvement = avg_metrics['avg_ssim_optimal'] - avg_metrics['avg_ssim']
    accuracy_improvement = avg_metrics['avg_accuracy_optimal'] - avg_metrics['avg_accuracy']
    
    print(f"\n📈 AVERAGE IMPROVEMENT WITH OPTIMAL THRESHOLD:")
    print(f"   SSIM Improvement:     {ssim_improvement:+.4f}")
    print(f"   Accuracy Improvement: {accuracy_improvement:+.4f} ({accuracy_improvement*100:+.2f}%)")
    
    print("="*70)
    
    # Performance interpretation
    print("\n📋 PERFORMANCE INTERPRETATION:")
    if avg_metrics['avg_ssim'] > 0.8:
        print("✅ SSIM: Excellent structural similarity")
    elif avg_metrics['avg_ssim'] > 0.6:
        print("⚠️  SSIM: Good structural similarity")
    else:
        print("❌ SSIM: Poor structural similarity")
    
    if avg_metrics['avg_rmse'] < 0.2:
        print("✅ RMSE: Low error rate")
    elif avg_metrics['avg_rmse'] < 0.4:
        print("⚠️  RMSE: Moderate error rate")
    else:
        print("❌ RMSE: High error rate")
    
    if avg_metrics['avg_accuracy'] > 0.9:
        print("✅ Accuracy: Excellent performance")
    elif avg_metrics['avg_accuracy'] > 0.8:
        print("⚠️  Accuracy: Good performance")
    else:
        print("❌ Accuracy: Poor performance")
    
    if ssim_improvement > 0.05:
        print("✅ Threshold Optimization: Significant improvement possible")
    elif ssim_improvement > 0.01:
        print("⚠️  Threshold Optimization: Modest improvement possible")
    else:
        print("❌ Threshold Optimization: Minimal improvement")

def visualize_results(result):
    """ENHANCED visualization of results"""
    plt.figure(figsize=(20, 15))
    
    # Original image
    plt.subplot(3, 4, 1)
    plt.imshow(result['original'], cmap='gray')
    plt.title('Original Image', fontsize=12)
    plt.axis('off')
    
    # Ground truth
    plt.subplot(3, 4, 2)
    plt.imshow(result['ground_truth'], cmap='gray')
    plt.title('Ground Truth (Sobel)', fontsize=12)
    plt.axis('off')
    
    # Model prediction (default threshold)
    plt.subplot(3, 4, 3)
    plt.imshow(result['prediction'], cmap='gray')
    plt.title(f'Model Prediction (0.3)\nSSIM: {result["ssim"]:.3f}', fontsize=12)
    plt.axis('off')
    
    # Optimal threshold prediction
    plt.subplot(3, 4, 4)
    plt.imshow(result['optimal_prediction'], cmap='gray')
    plt.title(f'Optimal Prediction ({result["optimal_threshold"]:.1f})\nSSIM: {result["ssim_optimal"]:.3f}', fontsize=12)
    plt.axis('off')
    
    # Probability map
    plt.subplot(3, 4, 5)
    plt.imshow(result['probability_map'], cmap='hot')
    plt.title('Probability Map', fontsize=12)
    plt.colorbar()
    plt.axis('off')
    
    # Difference map (default)
    plt.subplot(3, 4, 6)
    difference = cv2.absdiff(result['ground_truth'], result['prediction'])
    plt.imshow(difference, cmap='hot')
    plt.title('Error Map (Default)', fontsize=12)
    plt.axis('off')
    
    # Difference map (optimal)
    plt.subplot(3, 4, 7)
    difference_opt = cv2.absdiff(result['ground_truth'], result['optimal_prediction'])
    plt.imshow(difference_opt, cmap='hot')
    plt.title('Error Map (Optimal)', fontsize=12)
    plt.axis('off')
    
    # Threshold analysis
    plt.subplot(3, 4, 8)
    thresholds = list(result['threshold_metrics'].keys())
    ssim_values = [result['threshold_metrics'][t]['ssim'] for t in thresholds]
    plt.plot(thresholds, ssim_values, 'o-', linewidth=2, markersize=6)
    plt.axvline(x=result['optimal_threshold'], color='red', linestyle='--', label=f'Optimal: {result["optimal_threshold"]:.1f}')
    plt.axvline(x=0.3, color='blue', linestyle='--', label='Default: 0.3')
    plt.xlabel('Threshold')
    plt.ylabel('SSIM')
    plt.title('Threshold vs SSIM', fontsize=12)
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Metrics comparison
    plt.subplot(3, 4, 9)
    metrics = ['SSIM', 'Accuracy', '1-RMSE']
    default_values = [result['ssim'], result['accuracy'], 1-result['rmse']]
    optimal_values = [result['ssim_optimal'], result['accuracy_optimal'], 1-result['rmse_optimal']]
    
    x = np.arange(len(metrics))
    width = 0.35
    
    plt.bar(x - width/2, default_values, width, label='Default (0.3)', alpha=0.7)
    plt.bar(x + width/2, optimal_values, width, label=f'Optimal ({result["optimal_threshold"]:.1f})', alpha=0.7)
    
    plt.xlabel('Metrics')
    plt.ylabel('Score')
    plt.title('Default vs Optimal Threshold', fontsize=12)
    plt.xticks(x, metrics)
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Confusion matrix (default)
    plt.subplot(3, 4, 10)
    conf_matrix = np.array([[result['tn'], result['fp']], 
                           [result['fn'], result['tp']]])
    plt.imshow(conf_matrix, cmap='Blues', interpolation='nearest')
    plt.title('Confusion Matrix (Default)', fontsize=12)
    plt.colorbar()
    
    for i in range(2):
        for j in range(2):
            plt.text(j, i, f'{conf_matrix[i, j]:,}', 
                    ha='center', va='center', fontsize=10)
    
    plt.xticks([0, 1], ['Pred 0', 'Pred 1'])
    plt.yticks([0, 1], ['True 0', 'True 1'])
    
    # Model information
    plt.subplot(3, 4, 11)
    plt.axis('off')
    model_info = f"""
    MODEL: {current_model}
    
    DEFAULT THRESHOLD (0.3):
    SSIM: {result['ssim']:.4f}
    RMSE: {result['rmse']:.4f}
    Accuracy: {result['accuracy']:.4f}
    
    OPTIMAL THRESHOLD ({result['optimal_threshold']:.1f}):
    SSIM: {result['ssim_optimal']:.4f}
    RMSE: {result['rmse_optimal']:.4f}
    Accuracy: {result['accuracy_optimal']:.4f}
    
    IMPROVEMENT:
    SSIM: {result['ssim_optimal'] - result['ssim']:+.4f}
    Accuracy: {result['accuracy_optimal'] - result['accuracy']:+.4f}
    """
    plt.text(0.1, 0.9, model_info, fontsize=10, verticalalignment='top', 
             bbox=dict(boxstyle="round,pad=0.3", facecolor="lightblue"),
             family='monospace')
    plt.title('Performance Summary', fontsize=12)
    
    # Threshold sweep
    plt.subplot(3, 4, 12)
    thresholds = list(result['threshold_metrics'].keys())
    accuracy_values = [result['threshold_metrics'][t]['accuracy'] for t in thresholds]
    tpr_values = [result['threshold_metrics'][t]['tpr'] for t in thresholds]
    fpr_values = [result['threshold_metrics'][t]['fpr'] for t in thresholds]
    
    plt.plot(thresholds, accuracy_values, 'o-', label='Accuracy', linewidth=2)
    plt.plot(thresholds, tpr_values, 's-', label='TPR', linewidth=2)
    plt.plot(thresholds, fpr_values, '^-', label='FPR', linewidth=2)
    plt.axvline(x=result['optimal_threshold'], color='red', linestyle='--', alpha=0.7)
    
    plt.xlabel('Threshold')
    plt.ylabel('Score')
    plt.title('Threshold Analysis', fontsize=12)
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()

# =============================================================================
# MAIN EXECUTION - ENHANCED VERSION
# =============================================================================

if __name__== "__main__":
    print("🔧 ENHANCED MODEL PERFORMANCE EVALUATION TOOL")
    print("=" * 60)
    print("Choose evaluation mode:")
    print("1. Single image evaluation")
    print("2. Multiple images evaluation (folder)")
    print("3. Compare models performance (Extended vs Original)")
    
    choice = input("Enter your choice (1, 2, or 3): ").strip()
    
    if choice == "1":
        # Single image evaluation
        image_path = input("Enter image path: ").strip().strip('"')
        
        if not image_path:
            print("No image path provided. Exiting.")
        else:
            result = evaluate_single_image(image_path)
            if result:
                print_detailed_results(result)
                
                show_viz = input("\nShow detailed visualization? (y/n): ").strip().lower()
                if show_viz == 'y':
                    visualize_results(result)
    
    elif choice == "2":
        # Multiple images evaluation
        folder_path = input("Enter folder path containing images: ").strip().strip('"')
        
        if not folder_path:
            print("No folder path provided. Exiting.")
        else:
            results, avg_metrics = evaluate_multiple_images(folder_path)
            if results:
                print_summary_results(avg_metrics, len(results))
                
                # Ask if user wants to see individual results
                show_individual = input("\nShow individual image results? (y/n): ").strip().lower()
                if show_individual == 'y':
                    for result in results:
                        print_detailed_results(result)
                        
                        show_viz = input("Show visualization for this image? (y/n): ").strip().lower()
                        if show_viz == 'y':
                            visualize_results(result)
    
    elif choice == "3":
        # Compare models
        compare_models_performance()
    
    else:
        print("Invalid choice. Please run the script again and choose 1, 2, or 3.")