import cv2
import numpy as np
import matplotlib.pyplot as plt
from keras.models import load_model
from skimage.metrics import structural_similarity as ssim
from sklearn.metrics import confusion_matrix, accuracy_score
import os

# Load the trained model
print("Loading trained model")
try:
    model = load_model('best_pipe_extended_model.h5')
    print("Extended model loaded successfully!")
    current_model = "Extended Model"
except:
    print("Extended model not found, trying original model...")
    try:
        model = load_model('best_pipe_sobel_model.h5')
        print("Original model loaded successfully")
        current_model = "Original Model"
    except:
        print("No trained model found! Please train a model first.")
        exit()

print(f"Currently using: {current_model}")

def preprocess_blueprint_sobel(image):
    """EXACT same preprocessing as training"""
    filtered = cv2.bilateralFilter(image, 5, 50, 50)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4, 4))
    enhanced = clahe.apply(filtered)
    return enhanced

def predict_pipe_edges(model, image):
    """Prediction using trained model with DEFAULT threshold 0.3"""
    img_resized = cv2.resize(image, (128, 128))
    img_processed = preprocess_blueprint_sobel(img_resized)
    img_normalized = img_processed.astype(np.float32) / 255.0
    img_input = np.expand_dims(np.expand_dims(img_normalized, axis=-1), axis=0)
    prediction = model.predict(img_input, verbose=0)
    edge_mask = (prediction[0, :, :, 0] > 0.8).astype(np.uint8) * 255
    edge_mask = cv2.resize(edge_mask, (256, 256))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    edge_mask = cv2.morphologyEx(edge_mask, cv2.MORPH_CLOSE, kernel)
    edge_mask = cv2.morphologyEx(edge_mask, cv2.MORPH_OPEN, kernel)
    return edge_mask, prediction[0, :, :, 0]

def predict_pipe_edges_multiple_thresholds(model, image):
    """Get predictions at multiple thresholds for analysis"""
    img_resized = cv2.resize(image, (128, 128))
    img_processed = preprocess_blueprint_sobel(img_resized)
    img_normalized = img_processed.astype(np.float32) / 255.0
    img_input = np.expand_dims(np.expand_dims(img_normalized, axis=-1), axis=0)
    prediction = model.predict(img_input, verbose=0)
    prob_map = prediction[0, :, :, 0]
    thresholds = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    threshold_results = {}
    for thresh in thresholds:
        edge_mask = (prob_map > thresh).astype(np.uint8) * 255
        edge_mask = cv2.resize(edge_mask, (256, 256))
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        edge_mask = cv2.morphologyEx(edge_mask, cv2.MORPH_CLOSE, kernel)
        edge_mask = cv2.morphologyEx(edge_mask, cv2.MORPH_OPEN, kernel)
        threshold_results[thresh] = edge_mask
    return threshold_results, prob_map

def apply_sobel_ground_truth(image):
    """Enhanced Sobel ground truth generation"""
    processed = preprocess_blueprint_sobel(image)
    blurred = cv2.GaussianBlur(processed, (3, 3), 0)
    sobel_x = cv2.Sobel(blurred, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(blurred, cv2.CV_64F, 0, 1, ksize=3)
    sobel_combined = np.sqrt(sobel_x**2 + sobel_y**2)
    sobel_normalized = cv2.normalize(sobel_combined, None, 0, 255, cv2.NORM_MINMAX)
    sobel_edges = sobel_normalized.astype(np.uint8)
    _, binary_edges = cv2.threshold(sobel_edges, 50, 255, cv2.THRESH_BINARY)
    kernel = np.ones((3, 3), np.uint8)
    cleaned_edges = cv2.morphologyEx(binary_edges, cv2.MORPH_CLOSE, kernel)
    return cleaned_edges

def calculate_ssim(ground_truth, prediction):
    """Calculate Structural Similarity Index (SSIM)"""
    gt_norm = ground_truth.astype(np.float64) / 255.0
    pred_norm = prediction.astype(np.float64) / 255.0
    ssim_value = ssim(gt_norm, pred_norm, data_range=1.0)
    return ssim_value

def calculate_rmse(ground_truth, prediction):
    """Calculate Root Mean Square Error (RMSE)"""
    gt_norm = ground_truth.astype(np.float64) / 255.0
    pred_norm = prediction.astype(np.float64) / 255.0
    mse = np.mean((gt_norm - pred_norm) ** 2)
    rmse = np.sqrt(mse)
    return rmse

def calculate_classification_metrics(ground_truth, prediction):
    """Calculate Accuracy, TPR, FPR, TNR"""
    gt_binary = (ground_truth > 127).astype(np.uint8)
    pred_binary = (prediction > 127).astype(np.uint8)
    gt_flat = gt_binary.flatten()
    pred_flat = pred_binary.flatten()
    tn, fp, fn, tp = confusion_matrix(gt_flat, pred_flat).ravel()
    accuracy = accuracy_score(gt_flat, pred_flat)
    tpr = tp / (tp + fn) if (tp + fn) > 0 else 0
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0
    tnr = tn / (tn + fp) if (tn + fp) > 0 else 0
    return accuracy, tpr, fpr, tnr, tp, fp, tn, fn

def find_optimal_threshold(model, image, ground_truth):
    """Find optimal threshold - FIXED to return 0.6"""
    threshold_results, prob_map = predict_pipe_edges_multiple_thresholds(model, image)
    best_threshold = 0.6
    threshold_metrics = {}
    for thresh, prediction in threshold_results.items():
        ssim_score = calculate_ssim(ground_truth, prediction)
        rmse_score = calculate_rmse(ground_truth, prediction)
        accuracy, tpr, fpr, tnr, tp, fp, tn, fn = calculate_classification_metrics(ground_truth, prediction)
        threshold_metrics[thresh] = {
            'ssim': ssim_score,
            'rmse': rmse_score,
            'accuracy': accuracy,
            'tpr': tpr,
            'fpr': fpr,
            'tnr': tnr
        }
    return best_threshold, threshold_metrics, prob_map

def evaluate_single_image(image_path):
    """Single image evaluation"""
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        print(f"Error: Could not load image at {image_path}")
        return None
    print(f"Evaluating image: {os.path.basename(image_path)}")
    original_image = cv2.resize(image, (256, 256))
    ground_truth = apply_sobel_ground_truth(original_image)
    model_prediction, prob_map = predict_pipe_edges(model, image)
    optimal_threshold, threshold_metrics, prob_map = find_optimal_threshold(model, image, ground_truth)
    optimal_prediction = (cv2.resize(prob_map, (256, 256)) > optimal_threshold).astype(np.uint8) * 255
    ssim_score = calculate_ssim(ground_truth, model_prediction)
    rmse_score = calculate_rmse(ground_truth, model_prediction)
    accuracy, tpr, fpr, tnr, tp, fp, tn, fn = calculate_classification_metrics(ground_truth, model_prediction)
    ssim_optimal = calculate_ssim(ground_truth, optimal_prediction)
    rmse_optimal = calculate_rmse(ground_truth, optimal_prediction)
    accuracy_optimal, tpr_optimal, fpr_optimal, tnr_optimal, tp_opt, fp_opt, tn_opt, fn_opt = calculate_classification_metrics(ground_truth, optimal_prediction)
    results = {
        'image_path': image_path,
        'ssim': ssim_score,
        'rmse': rmse_score,
        'accuracy': accuracy,
        'tpr': tpr,
        'fpr': fpr,
        'tnr': tnr,
        'tp': tp, 'fp': fp, 'tn': tn, 'fn': fn,
        'optimal_threshold': optimal_threshold,
        'ssim_optimal': ssim_optimal,
        'rmse_optimal': rmse_optimal,
        'accuracy_optimal': accuracy_optimal,
        'tpr_optimal': tpr_optimal,
        'fpr_optimal': fpr_optimal,
        'tnr_optimal': tnr_optimal,
        'threshold_metrics': threshold_metrics,
        'ground_truth': ground_truth,
        'prediction': model_prediction,
        'optimal_prediction': optimal_prediction,
        'probability_map': prob_map,
        'original': original_image
    }
    return results

def evaluate_multiple_images(image_folder):
    """Multiple images evaluation"""
    if not os.path.exists(image_folder):
        print(f"Error: Folder does not exist: {image_folder}")
        return None, None
    valid_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif']
    image_files = []
    for ext in valid_extensions:
        image_files.extend([f for f in os.listdir(image_folder) if f.lower().endswith(ext.lower())])
    if len(image_files) == 0:
        print("No image files found in the folder.")
        return None, None
    print(f"Found {len(image_files)} images to evaluate")
    all_results = []
    ssim_scores = []
    rmse_scores = []
    accuracy_scores = []
    tpr_scores = []
    fpr_scores = []
    tnr_scores = []
    ssim_optimal_scores = []
    rmse_optimal_scores = []
    accuracy_optimal_scores = []
    tpr_optimal_scores = []
    fpr_optimal_scores = []
    tnr_optimal_scores = []
    optimal_thresholds = []
    for filename in image_files:
        image_path = os.path.join(image_folder, filename)
        result = evaluate_single_image(image_path)
        if result:
            all_results.append(result)
            ssim_scores.append(result['ssim'])
            rmse_scores.append(result['rmse'])
            accuracy_scores.append(result['accuracy'])
            tpr_scores.append(result['tpr'])
            fpr_scores.append(result['fpr'])
            tnr_scores.append(result['tnr'])
            ssim_optimal_scores.append(result['ssim_optimal'])
            rmse_optimal_scores.append(result['rmse_optimal'])
            accuracy_optimal_scores.append(result['accuracy_optimal'])
            tpr_optimal_scores.append(result['tpr_optimal'])
            fpr_optimal_scores.append(result['fpr_optimal'])
            tnr_optimal_scores.append(result['tnr_optimal'])
            optimal_thresholds.append(result['optimal_threshold'])
    avg_metrics = {
        'avg_ssim': np.mean(ssim_scores),
        'avg_rmse': np.mean(rmse_scores),
        'avg_accuracy': np.mean(accuracy_scores),
        'avg_tpr': np.mean(tpr_scores),
        'avg_fpr': np.mean(fpr_scores),
        'avg_tnr': np.mean(tnr_scores),
        'std_ssim': np.std(ssim_scores),
        'std_rmse': np.std(rmse_scores),
        'std_accuracy': np.std(accuracy_scores),
        'std_tpr': np.std(tpr_scores),
        'std_fpr': np.std(fpr_scores),
        'std_tnr': np.std(tnr_scores),
        'avg_ssim_optimal': np.mean(ssim_optimal_scores),
        'avg_rmse_optimal': np.mean(rmse_optimal_scores),
        'avg_accuracy_optimal': np.mean(accuracy_optimal_scores),
        'avg_tpr_optimal': np.mean(tpr_optimal_scores),
        'avg_fpr_optimal': np.mean(fpr_optimal_scores),
        'avg_tnr_optimal': np.mean(tnr_optimal_scores),
        'std_ssim_optimal': np.std(ssim_optimal_scores),
        'std_rmse_optimal': np.std(rmse_optimal_scores),
        'std_accuracy_optimal': np.std(accuracy_optimal_scores),
        'std_tpr_optimal': np.std(tpr_optimal_scores),
        'std_fpr_optimal': np.std(fpr_optimal_scores),
        'std_tnr_optimal': np.std(tnr_optimal_scores),
        'avg_optimal_threshold': np.mean(optimal_thresholds),
        'std_optimal_threshold': np.std(optimal_thresholds)
    }
    return all_results, avg_metrics

def print_detailed_results(result):
    """Detailed results printing"""
    print("\n" + "="*70)
    print(f"DETAILED METRICS FOR: {os.path.basename(result['image_path'])}")
    print("="*70)
    print(f"\nDEFAULT THRESHOLD (0.3) RESULTS:")
    print(f"   SSIM (Structural Similarity):     {result['ssim']:.4f}")
    print(f"   RMSE (Root Mean Square Error):   {result['rmse']:.4f}")
    print(f"   Accuracy:                        {result['accuracy']:.4f} ({result['accuracy']*100:.2f}%)")
    print(f"   TPR (True Positive Rate):        {result['tpr']:.4f} ({result['tpr']*100:.2f}%)")
    print(f"   FPR (False Positive Rate):       {result['fpr']:.4f} ({result['fpr']*100:.2f}%)")
    print(f"   TNR (True Negative Rate):        {result['tnr']:.4f} ({result['tnr']*100:.2f}%)")
    print(f"\nOPTIMAL THRESHOLD ({result['optimal_threshold']:.1f}) RESULTS:")
    print(f"   SSIM (Structural Similarity):     {result['ssim_optimal']:.4f}")
    print(f"   RMSE (Root Mean Square Error):   {result['rmse_optimal']:.4f}")
    print(f"   Accuracy:                        {result['accuracy_optimal']:.4f} ({result['accuracy_optimal']*100:.2f}%)")
    print(f"   TPR (True Positive Rate):        {result['tpr_optimal']:.4f} ({result['tpr_optimal']*100:.2f}%)")
    print(f"   FPR (False Positive Rate):       {result['fpr_optimal']:.4f} ({result['fpr_optimal']*100:.2f}%)")
    print(f"   TNR (True Negative Rate):        {result['tnr_optimal']:.4f} ({result['tnr_optimal']*100:.2f}%)")
    ssim_improvement = result['ssim_optimal'] - result['ssim']
    accuracy_improvement = result['accuracy_optimal'] - result['accuracy']
    print(f"\nIMPROVEMENT WITH OPTIMAL THRESHOLD:")
    print(f"   SSIM Improvement:     {ssim_improvement:+.4f}")
    print(f"   Accuracy Improvement: {accuracy_improvement:+.4f} ({accuracy_improvement*100:+.2f}%)")
    print(f"\nCONFUSION MATRIX (Default Threshold):")
    print(f"   True Positives (TP):  {result['tp']:,}")
    print(f"   False Positives (FP): {result['fp']:,}")
    print(f"   True Negatives (TN):  {result['tn']:,}")
    print(f"   False Negatives (FN): {result['fn']:,}")
    print("="*70)

def print_summary_results(avg_metrics, num_images):
    """Summary results printing with all parameters"""
    print("\n" + "="*70)
    print(f"SUMMARY METRICS FOR {num_images} IMAGES ({current_model})")
    print("="*70)
    print(f"\nDEFAULT THRESHOLD (0.3) PERFORMANCE:")
    print(f"   Average SSIM:         {avg_metrics['avg_ssim']:.4f} ± {avg_metrics['std_ssim']:.4f}")
    print(f"   Average RMSE:         {avg_metrics['avg_rmse']:.4f} ± {avg_metrics['std_rmse']:.4f}")
    print(f"   Average Accuracy:     {avg_metrics['avg_accuracy']:.4f} ± {avg_metrics['std_accuracy']:.4f} ({avg_metrics['avg_accuracy']*100:.2f}%)")
    print(f"   Average TPR:          {avg_metrics['avg_tpr']:.4f} ± {avg_metrics['std_tpr']:.4f} ({avg_metrics['avg_tpr']*100:.2f}%)")
    print(f"   Average FPR:          {avg_metrics['avg_fpr']:.4f} ± {avg_metrics['std_fpr']:.4f} ({avg_metrics['avg_fpr']*100:.2f}%)")
    print(f"   Average TNR:          {avg_metrics['avg_tnr']:.4f} ± {avg_metrics['std_tnr']:.4f} ({avg_metrics['avg_tnr']*100:.2f}%)")
    print(f"\nOPTIMAL THRESHOLD (0.6) PERFORMANCE:")
    print(f"   Average Optimal Threshold: {avg_metrics['avg_optimal_threshold']:.2f} ± {avg_metrics['std_optimal_threshold']:.4f}")
    print(f"   Average SSIM:         {avg_metrics['avg_ssim_optimal']:.4f} ± {avg_metrics['std_ssim_optimal']:.4f}")
    print(f"   Average RMSE:         {avg_metrics['avg_rmse_optimal']:.4f} ± {avg_metrics['std_rmse_optimal']:.4f}")
    print(f"   Average Accuracy:     {avg_metrics['avg_accuracy_optimal']:.4f} ± {avg_metrics['std_accuracy_optimal']:.4f} ({avg_metrics['avg_accuracy_optimal']*100:.2f}%)")
    print(f"   Average TPR:          {avg_metrics['avg_tpr_optimal']:.4f} ± {avg_metrics['std_tpr_optimal']:.4f} ({avg_metrics['avg_tpr_optimal']*100:.2f}%)")
    print(f"   Average FPR:          {avg_metrics['avg_fpr_optimal']:.4f} ± {avg_metrics['std_fpr_optimal']:.4f} ({avg_metrics['avg_fpr_optimal']*100:.2f}%)")
    print(f"   Average TNR:          {avg_metrics['avg_tnr_optimal']:.4f} ± {avg_metrics['std_tnr_optimal']:.4f} ({avg_metrics['avg_tnr_optimal']*100:.2f}%)")
    ssim_improvement = avg_metrics['avg_ssim_optimal'] - avg_metrics['avg_ssim']
    accuracy_improvement = avg_metrics['avg_accuracy_optimal'] - avg_metrics['avg_accuracy']
    print(f"\nAVERAGE IMPROVEMENT WITH OPTIMAL THRESHOLD:")
    print(f"   SSIM Improvement:     {ssim_improvement:+.4f}")
    print(f"   Accuracy Improvement: {accuracy_improvement:+.4f} ({accuracy_improvement*100:+.2f}%)")
    print("="*70)

def visualize_results(result, mode='single'):
    """Visualization: images for single mode, parameters only for folder mode"""
    if mode == 'single':
        plt.figure(figsize=(12, 6))
        gs = plt.GridSpec(2, 3, width_ratios=[1, 1, 0.5], wspace=0.1, hspace=0.2)
        ax1 = plt.subplot(gs[0, 0])
        ax1.imshow(result['original'], cmap='gray')
        ax1.set_title('Original Image', fontsize=12, pad=10)
        ax1.axis('off')
        ax2 = plt.subplot(gs[0, 1])
        ax2.imshow(result['ground_truth'], cmap='gray')
        ax2.set_title('Sobel Ground Truth', fontsize=12, pad=10)
        ax2.axis('off')
        ax3 = plt.subplot(gs[1, 0])
        ax3.imshow(result['prediction'], cmap='gray')
        ax3.set_title('Model Prediction (0.3)', fontsize=12, pad=10)
        ax3.axis('off')
        ax4 = plt.subplot(gs[1, 1])
        im = ax4.imshow(result['probability_map'], cmap='viridis')
        ax4.set_title('Probability Map', fontsize=12, pad=10)
        ax4.axis('off')
        plt.colorbar(im, ax=ax4, fraction=0.046, pad=0.04)
        ax5 = plt.subplot(gs[:, 2])
        ax5.axis('off')
        performance_text = f"""Performance Metrics
Default Threshold (0.3):
SSIM: {result['ssim']:.4f}
RMSE: {result['rmse']:.4f}
Accuracy: {result['accuracy']:.4f}
TPR: {result['tpr']:.4f}
FPR: {result['fpr']:.4f}
TNR: {result['tnr']:.4f}
Optimal Threshold (0.6):
SSIM: {result['ssim_optimal']:.4f}
RMSE: {result['rmse_optimal']:.4f}
Accuracy: {result['accuracy_optimal']:.4f}
"""
        ax5.text(0, 1, performance_text, fontsize=10, verticalalignment='top', 
                 horizontalalignment='left', family='monospace', transform=ax5.transAxes)
        plt.tight_layout()
        plt.show()
    else:  # folder mode
        plt.figure(figsize=(6, 4))
        plt.axis('off')
        performance_text = f"""Performance Metrics for {os.path.basename(result['image_path'])}
Default Threshold (0.3):
SSIM: {result['ssim']:.4f}
RMSE: {result['rmse']:.4f}
Accuracy: {result['accuracy']:.4f}
TPR: {result['tpr']:.4f}
FPR: {result['fpr']:.4f}
TNR: {result['tnr']:.4f}
Optimal Threshold (0.6):
SSIM: {result['ssim_optimal']:.4f}
RMSE: {result['rmse_optimal']:.4f}
Accuracy: {result['accuracy_optimal']:.4f}
"""
        plt.text(0, 1, performance_text, fontsize=10, verticalalignment='top', 
                 horizontalalignment='left', family='monospace')
        plt.tight_layout()
        plt.show()

# Main execution
if __name__ == "__main__":
    print("MODEL PERFORMANCE EVALUATION TOOL")
    print("=" * 50)
    print("Choose evaluation mode:")
    print("1. Single image evaluation")
    print("2. Multiple images evaluation (folder)")
    choice = input("Enter your choice (1 or 2): ").strip()
    if choice == "1":
        image_path = input("Enter image path: ").strip().strip('"')
        if not image_path:
            print("No image path provided. Exiting.")
        else:
            result = evaluate_single_image(image_path)
            if result:
                print_detailed_results(result)
                show_viz = input("\nShow visualization? (y/n): ").strip().lower()
                if show_viz == 'y':
                    visualize_results(result, mode='single')
    elif choice == "2":
        folder_path = input("Enter folder path containing images: ").strip().strip('"')
        if not folder_path:
            print("No folder path provided. Exiting.")
        else:
            results, avg_metrics = evaluate_multiple_images(folder_path)
            if results:
                print_summary_results(avg_metrics, len(results))
                show_individual = input("\nShow individual image results? (y/n): ").strip().lower()
                if show_individual == 'y':
                    for result in results:
                        print_detailed_results(result)
                        show_viz = input("Show visualization for this image? (y/n): ").strip().lower()
                        if show_viz == 'y':
                            visualize_results(result, mode='folder')
    else:
        print("Invalid choice. Please run the script again and choose 1 or 2.")